<?php
defined('BASEPATH') or die("No Access Allowed");
?>
<div class="text-center" style="padding-top:20px;padding-bottom:40px;">
   <div style="padding-bottom:10px">
      <img src="./assets/img/ipm.png" class="img-thanks" alt="Slideshow 1" >
   </div>
   <div class="kata ">
      <h2 >TERIMAKASIH SUDAH MEMILIH <br>CALON FORMATUR</h2>
      <p>PR IPM SMK MUHAMMADIYAH 2 PEKANBARU</p>
      <a href="./" type="button" class="btn btn-outline-success">Back to Home</a>
   </div>
   
</div>
